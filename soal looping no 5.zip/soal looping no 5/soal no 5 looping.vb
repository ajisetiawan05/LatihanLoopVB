﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim x, y, a, b, c, d, k, f, g As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For x = 0 To 20
            If x = 0 Then
                a = x + 4
            ElseIf x = 4 Then
                b = x * 2
            ElseIf x = 8 Then
                c = x * 2
            End If
        Next x

        For y = 0 To 54
            If y = 0 Then
                k = y + 6
            ElseIf y = 6 Then
                f = y * 3
            ElseIf y = 18 Then
                g = y * 3
            End If
        Next y
        TextBox1.Text = a & wrap & k & wrap & b & wrap & f & wrap & c & wrap & g & wrap
    End Sub
End Class
