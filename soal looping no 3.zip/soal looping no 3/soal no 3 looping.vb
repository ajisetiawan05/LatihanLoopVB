﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim x, y, a, b, c, d, k, f, g As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For x = 0 To 243
            If x = 0 Then
                a = x + 243
            ElseIf x = 243 Then
                b = x / 3
            ElseIf x = 81 Then
                c = x / 3
            ElseIf x = 27 Then
                d = x / 3
            ElseIf x = 9 Then
                f = x / 3
            ElseIf x = 3 Then
                g = x / 3
            End If
        Next x
        TextBox1.Text = a & wrap & b & wrap & c & wrap & d & wrap & f & wrap & g & wrap
    End Sub
End Class
