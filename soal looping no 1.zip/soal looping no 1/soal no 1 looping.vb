﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim x, y, a, b, c, d, k, f, g As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For x = 0 To 20
            If x = 0 Then
                a = x + 2
            ElseIf x = 2 Then
                b = x + 6
            ElseIf x = 8 Then
                c = x + 6
            ElseIf x = 14 Then
                d = x + 6
            End If
        Next x

        For y = 0 To 25
            If y = 0 Then
                k = y + 4
            ElseIf y = 4 Then
                f = y + 10
            ElseIf y = 14 Then
                g = y + 10
            End If
        Next y
        TextBox1.Text = a & wrap & k & wrap & b & wrap & f & wrap & c & wrap & g & wrap & d & wrap
    End Sub
End Class
